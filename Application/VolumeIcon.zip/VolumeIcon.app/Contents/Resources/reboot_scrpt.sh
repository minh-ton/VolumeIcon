#!/bin/sh

#  reboot_scrpt.sh
#  
#
#  Created by Ford on 1/4/20.
#  

echo
reboot

