#!/bin/sh

#  step2_delete.sh
#  
#
#  Created by Ford on 1/4/20.
#  

rm /tmp/vi_main.zip
exit
